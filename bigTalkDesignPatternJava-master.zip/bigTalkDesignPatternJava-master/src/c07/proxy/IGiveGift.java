package c07.proxy;

/**
 * 介面，定義各種送禮行為
 *
 */
public interface IGiveGift {
	public void giveDolls();
	public void giveFlowers();
	public void giveChocolate();
}
