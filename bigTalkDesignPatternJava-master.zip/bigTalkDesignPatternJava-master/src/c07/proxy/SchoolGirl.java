package c07.proxy;

/**
 * 接受禮物的女學生 
 */
public class SchoolGirl {
	public String name;
}
