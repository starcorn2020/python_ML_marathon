package c08.factory;

/**
 * 南丁格爾工廠
 * @author Yan
 *
 */
public interface IFactory {
	public Nightingale CreateNightingale();
}
