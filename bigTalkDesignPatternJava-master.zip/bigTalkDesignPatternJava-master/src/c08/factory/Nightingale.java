package c08.factory;

/**
 * 
 * 南丁格爾類別，有各種幫助老人起居生活的方法
 *
 */
public class Nightingale {
	public void sweep(){
		System.out.println("掃地");
	}
	public void wash(){
		System.out.println("洗衣");
	}
	public void buyRice(){
		System.out.println("買米");
	}
}
