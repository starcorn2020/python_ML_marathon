package c08.factory;

/**
 * 
 * 希望以南丁格爾精神服務社區老人的熱心大學生類別
 *
 */
public class Undergraduate extends Nightingale{

}
