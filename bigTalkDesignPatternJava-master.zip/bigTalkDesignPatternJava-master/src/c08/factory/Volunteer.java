package c08.factory;

/**
 * 
 * 希望以南丁格爾精神服務社區老人的社區義工
 *
 */
public class Volunteer extends Nightingale{
	
}
