package c10.template;

public class TestPaperB extends TestPaper{

	@Override
	protected String answerA() {
		return "c";
	}

	@Override
	protected String answerB() {
		return "a";
	}

	@Override
	protected String answerC() {
		return "a";
	}
}
