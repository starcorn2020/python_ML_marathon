package c16.state;

public interface State {
	void writeProgram(Work work);
}
