package c22.bridge;

/**
 * 手機通訊錄
 * @author Yan
 *
 */
public class HandsetContactList implements HandsetSoft {

	@Override
	public void run() {
		System.out.println("執行手機通訊錄");
	}

}
