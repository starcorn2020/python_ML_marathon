package c22.bridge;

/**
 * 手機遊戲
 * @author Yan
 *
 */
public class HandsetGame implements HandsetSoft {

	@Override
	public void run() {
		System.out.println("執行手機遊戲");
	}

}
