package c22.bridge;
/**
 * 手機軟體介面
 * @author Yan
 *
 */
public interface HandsetSoft {
	/**
	 * 執行軟體
	 */
	void run();
}
