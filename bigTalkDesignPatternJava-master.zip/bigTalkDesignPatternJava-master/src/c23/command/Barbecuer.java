package c23.command;
/**
 * 烤肉串廚師
 * @author Yan
 *
 */
public class Barbecuer {
	/**
	 * 烤羊肉
	 */
	public void bakeMutton(){
		System.out.println("烤羊肉串");
	}
	
	/**
	 * 烤雞翅
	 */
	public void bakeChickenWing(){
		System.out.println("烤雞翅");
	}
}
