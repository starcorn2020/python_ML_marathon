package c26.flywight;

/**
 * 網站
 * @author Yan
 *
 */
public interface Website {
	void use(User user);
}
